#ifndef MATERIAL_H
#define MATERIAL_H
//==============================================================================================
// Originally written in 2016 by Peter Shirley <ptrshrl@gmail.com>
//
// To the extent possible under law, the author(s) have dedicated all copyright and related and
// neighboring rights to this software to the public domain worldwide. This software is
// distributed without any warranty.
//
// You should have received a copy (see file COPYING.txt) of the CC0 Public Domain Dedication
// along with this software. If not, see <http://creativecommons.org/publicdomain/zero/1.0/>.
//==============================================================================================

#include "common/rtweekend.h"


struct hit_record;


class material {
    public:
        virtual bool scatter(
            const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered, int rand_det
        ) = 0;
};

vec3 scatter_det[100] = {unit_vector(vec3(0.0244448336306959, 0.0869719425681978, 0.148835292318836)),
unit_vector(vec3(0.101324288873002, 0.0611958121880889, 0.14718405646272)),
unit_vector(vec3(0.0536037627607584, 0.618352535180748, 0.718149414053187)),
unit_vector(vec3(0.660479538608342, 0.0237768883816898, 0.393281672149897)),
unit_vector(vec3(0.294039444299415, 0.518725374247879, 0.488685985794291)),
unit_vector(vec3(0.435598120326176, 0.478925955481827, 0.135060024214908)),
unit_vector(vec3(0.486945019336417, 0.267399958102033, 0.329355177469552)),
unit_vector(vec3(0.195677104406059, 0.785932143917307, 0.163258581887931)),
unit_vector(vec3(0.229084966471419, 0.540637927828357, 0.321338581154123)),
unit_vector(vec3(0.206256930250674, 0.12837560265325, 0.412313237087801)),
unit_vector(vec3(0.796115016564727, 0.0620699343271554, 0.195465288124979)),
unit_vector(vec3(0.0424728505313396, 0.555207123747095, 0.323234457755461)),
unit_vector(vec3(0.728541820310056, 0.393267214298248, 0.400597882922739)),
unit_vector(vec3(0.426404058001935, 0.534319466445595, 0.116590920370072)),
unit_vector(vec3(0.56857990543358, 0.320515408879146, 0.629390367073938)),
unit_vector(vec3(0.712538145016879, 0.0833148425444961, 0.0877338538412005)),
unit_vector(vec3(0.61819272628054, 0.127469869097695, 0.251448612893)),
unit_vector(vec3(0.0441003981977701, 0.159747408470139, 0.734249972505495)),
unit_vector(vec3(0.471157568506896, 0.48333412152715, 0.460576032986864)),
unit_vector(vec3(0.679299891926348, 0.125328745227307, 0.396119663724676)),
unit_vector(vec3(0.0963721650186926, 0.66838123020716, 0.513986919540912)),
unit_vector(vec3(0.367446447024122, 0.552556813927367, 0.0693607695866376)),
unit_vector(vec3(0.27791348635219, 0.528511765180156, 0.408328772522509)),
unit_vector(vec3(0.0839151747059077, 0.120318822795525, 0.706974967150018)),
unit_vector(vec3(0.330096873221919, 0.164321308489889, 0.38287496403791)),
unit_vector(vec3(0.646780133247375, 0.215425621252507, 0.138463590992615)),
unit_vector(vec3(0.130260383011773, 0.437928363448009, 0.766784061212093)),
unit_vector(vec3(0.294988392153755, 0.230257550021634, 0.156340630957857)),
unit_vector(vec3(0.479886265238747, 0.461579836672172, 0.644542925292626)),
unit_vector(vec3(0.0507619385607541, 0.275736273732036, 0.823552365647629)),
unit_vector(vec3(0.5374043462798, 0.0133424210362136, 0.323593873996288)),
unit_vector(vec3(0.576332118129358, 0.313597678672522, 0.593222309835255)),
unit_vector(vec3(0.23875144473277, 0.251506096450612, 0.263690102146938)),
unit_vector(vec3(0.0977123577613384, 0.691902094520628, 0.0845900205895305)),
unit_vector(vec3(0.00109341298229992, 0.318285983754322, 0.427140813553706)),
unit_vector(vec3(0.122638068394735, 0.410718271275982, 0.449694303562865)),
unit_vector(vec3(0.526711142854765, 0.183364314259961, 0.00739551987498999)),
unit_vector(vec3(0.481964553706348, 0.299785433104262, 0.550078314030543)),
unit_vector(vec3(0.0516786468215287, 0.59027630626224, 0.682555010542274)),
unit_vector(vec3(0.644834630656987, 0.0990330041386187, 0.645577965304255)),
unit_vector(vec3(0.472960684681311, 0.647747421637177, 0.524640041403472)),
unit_vector(vec3(0.493124504806474, 0.618655834812671, 0.0460024063941091)),
unit_vector(vec3(0.265623817918822, 0.525116046424955, 0.212597157573327)),
unit_vector(vec3(0.0263698094058782, 0.226157690864056, 0.911479200934991)),
unit_vector(vec3(0.189595555188134, 0.204439090099186, 0.0893509208690375)),
unit_vector(vec3(0.282047411659732, 0.738395636435598, 0.170546026900411)),
unit_vector(vec3(0.29417805117555, 0.00202545151114464, 0.617499227402732)),
unit_vector(vec3(0.962526851799339, 0.0836189645342529, 0.0440695064608008)),
unit_vector(vec3(0.324955428717658, 0.191971234977245, 0.389473851537332)),
unit_vector(vec3(0.110240645473823, 0.580926357302815, 0.533316252985969)),
unit_vector(vec3(0.227633130503818, 0.203188077546656, 0.945299217477441)),
unit_vector(vec3(0.242213071556762, 0.668969341320917, 0.665186949074268)),
unit_vector(vec3(0.384180882945657, 0.681817366974428, 0.447219153400511)),
unit_vector(vec3(0.564169293502346, 0.607395793078467, 0.53794714435935)),
unit_vector(vec3(0.569614531937987, 0.52323640906252, 0.285151593387127)),
unit_vector(vec3(0.102394618559629, 0.268866661237553, 0.899315047543496)),
unit_vector(vec3(0.071268821367994, 0.0392904346808791, 0.505921131465584)),
unit_vector(vec3(0.443074340000749, 0.324247000273317, 0.574633529409766)),
unit_vector(vec3(0.570326762041077, 0.313585517695174, 0.180706026498228)),
unit_vector(vec3(0.527816099114716, 0.406193731585518, 0.00943213631398976)),
unit_vector(vec3(0.224518940784037, 0.565927293850109, 0.35774352028966)),
unit_vector(vec3(0.520490394439548, 0.0988504004199058, 0.045961843803525)),
unit_vector(vec3(0.386010460555553, 0.281560690607876, 0.641530847642571)),
unit_vector(vec3(0.0294175259768963, 0.180103732738644, 0.381209082901478)),
unit_vector(vec3(0.418621604330838, 0.29075416084379, 0.768518552882597)),
unit_vector(vec3(0.071436969563365, 0.21113871387206, 0.913097790908068)),
unit_vector(vec3(0.405651372391731, 0.480218335520476, 0.511111624538898)),
unit_vector(vec3(0.199780383845791, 0.801161823561415, 0.452649089507759)),
unit_vector(vec3(0.57292241952382, 0.050718838814646, 0.0140697555616498)),
unit_vector(vec3(0.112521913135424, 0.760025675408542, 0.515744657954201)),
unit_vector(vec3(0.0187353920191526, 0.388454667991027, 0.218509822385386)),
unit_vector(vec3(0.286152529995888, 0.342074262676761, 0.799176145577803)),
unit_vector(vec3(0.0801801304332912, 0.032115139067173, 0.126639867899939)),
unit_vector(vec3(0.0833484092727304, 0.0375945132691413, 0.0703461980447173)),
unit_vector(vec3(0.161371741443872, 0.0350200536195189, 0.785255642142147)),
unit_vector(vec3(0.385328046046197, 0.725158446002752, 0.00687761045992374)),
unit_vector(vec3(0.12611842318438, 0.798095050035045, 0.065748255001381)),
unit_vector(vec3(0.222236613044515, 0.0797405664343387, 0.882717236410826)),
unit_vector(vec3(0.149420181522146, 0.472086643101647, 0.4438098478131)),
unit_vector(vec3(0.0109346280805767, 0.0970029088202864, 0.929746186360717)),
unit_vector(vec3(0.00277540367096663, 0.321760629070923, 0.511253370903432)),
unit_vector(vec3(0.507474482059479, 0.582011125748977, 0.17946664034389)),
unit_vector(vec3(0.17551043536514, 0.640924843493849, 0.729186530923471)),
unit_vector(vec3(0.266340041300282, 0.425170055823401, 0.46480797464028)),
unit_vector(vec3(0.690353919286281, 0.0575024376157671, 0.282385572325438)),
unit_vector(vec3(0.618139830883592, 0.538231106474996, 0.354976553935558)),
unit_vector(vec3(0.340674907201901, 0.342040738789365, 0.32564281206578)),
unit_vector(vec3(0.243615835905075, 0.201555048581213, 0.519197308225557)),
unit_vector(vec3(0.165486763697118, 0.194840339245275, 0.458534794859588)),
unit_vector(vec3(0.809352074051276, 0.353151660645381, 0.02343441080302)),
unit_vector(vec3(0.542101519880816, 0.26157994242385, 0.0846533058211207)),
unit_vector(vec3(0.291899140924215, 0.228510411689058, 0.915346568683162)),
unit_vector(vec3(0.454591364599764, 0.0435270573943853, 0.361158584011719)),
unit_vector(vec3(0.593751784414053, 0.613838695921004, 0.431217066477984)),
unit_vector(vec3(0.18198047298938, 0.584897980792448, 0.645638460293412)),
unit_vector(vec3(0.0722996233962476, 0.313330440083519, 0.507204500492662)),
unit_vector(vec3(0.101728259352967, 0.911380504025146, 0.163555639097467)),
unit_vector(vec3(0.29254536726512, 0.838040004950017, 0.200351966312155)),
unit_vector(vec3(0.669640809530392, 0.409364858875051, 0.600019430043176)),
unit_vector(vec3(0.573517828015611, 0.673545049503446, 0.334272280335426))};

class lambertian : public material {
    public:

        lambertian(const color& a){
          albedo = a;
          e = 1;
        }

        virtual bool scatter(
            const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered, int rand_det
        ) override {
            auto scatter_direction = rec.normal + scatter_det[rand_det];
            e++;
            if(e>99) e=0;

            // Catch degenerate scatter direction
            if (scatter_direction.near_zero())
                scatter_direction = rec.normal;

            scattered = ray(rec.p, scatter_direction);
            attenuation = albedo;
            return true;
        }

    public:
        int e;
        color albedo;
};


class metal : public material {
    public:
        metal(const color& a, double f) : albedo(a), fuzz(f < 1 ? f : 1) {}

        virtual bool scatter(
            const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered, int rand_det
        ) override {
            vec3 reflected = reflect(unit_vector(r_in.direction()), rec.normal);
            scattered = ray(rec.p, reflected + fuzz*vec3(0, 1, 0));
            attenuation = albedo;
            return (dot(scattered.direction(), rec.normal) > 0);
        }

    public:
        color albedo;
        double fuzz;
};


class dielectric : public material {
    public:
        dielectric(double index_of_refraction) : ir(index_of_refraction) {}

        virtual bool scatter(
            const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered, int rand_det
        ) override {
            attenuation = color(1.0, 1.0, 1.0);
            double refraction_ratio = rec.front_face ? (1.0/ir) : ir;

            vec3 unit_direction = unit_vector(r_in.direction());
            double cos_theta = fmin(dot(-unit_direction, rec.normal), 1.0);
            double sin_theta = sqrt(1.0 - cos_theta*cos_theta);

            bool cannot_refract = refraction_ratio * sin_theta > 1.0;
            vec3 direction;

            if (cannot_refract || reflectance(cos_theta, refraction_ratio) > 0.5)
                direction = reflect(unit_direction, rec.normal);
            else
                direction = refract(unit_direction, rec.normal, refraction_ratio);

            scattered = ray(rec.p, direction);
            return true;
        }

    public:
        double ir; // Index of Refraction

    private:
        static double reflectance(double cosine, double ref_idx) {
            // Use Schlick's approximation for reflectance.
            auto r0 = (1-ref_idx) / (1+ref_idx);
            r0 = r0*r0;
            return r0 + (1-r0)*pow((1 - cosine),5);
        }
};


#endif
