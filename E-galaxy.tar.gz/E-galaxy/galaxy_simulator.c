/*
 * File: galaxy_simulator.c
 * --------------
 * Implements the bruto force algorithm for n-body
 * simulation with galaxy-like initial conditions.
 */
#include "galaxy_simulator.h"

//Some constants and global variables
int N = 2500;
int time_steps = 100;
const double L = 1, W = 1, dt = 1e-3, alpha = 0.25, V = 50, epsilon = 1e-1, grav = 0.04; //grav should be 100/N
double *x, *y, *u, *v, *force_x, *force_y, *mass;
struct node_t *root;

/*
 * Function to read a case
 */
int read_case (char *filename)
{
  int i, n;
  FILE *arq = NULL;
  if (filename) {
    arq = fopen(filename, "r");
  }else{
    arq = stdin;
  }
  if (arq == NULL){
    printf("Error: %s could not be opened.\n", filename);
    return 1;
  }
  n = fscanf(arq, "%d", &N);
  if (n != 1){
    printf("Error: %s could not be read for number of particles.\n", filename);
    fclose(arq);
    return 1;
  }

  //Initiate memory for the vectors
  x = (double *)malloc(N*sizeof(double));
  y = (double *)malloc(N*sizeof(double));
  u = (double *)malloc(N*sizeof(double));
  v = (double *)malloc(N*sizeof(double));
  force_x = (double *)calloc(N, sizeof(double));
  force_y = (double *)calloc(N, sizeof(double));
  mass = (double *)malloc(N*sizeof(double));
  if (x == NULL || y == NULL ||
      u == NULL || v == NULL ||
      force_x == NULL || force_y == NULL ||
      mass == NULL){
    printf("Error: some malloc won't work.\n");
    fclose(arq);
    return 1;
  }

  for (i = 0; i < N; i++){
    n = fscanf(arq, "%lf %lf %lf %lf %lf",
	       &mass[i], &x[i], &y[i], &u[i], &v[i]);
    if (n != 5) {
      printf("Error: Some reading won't work at line %d (%d)\n", i+1, n);
      fclose(arq);
      return 1;
    }
  }

  fclose(arq);
  return 0;
}

/*
 * Function to free a case
 */
void free_case ()
{
  free(x);
  free(y);
  free(u);
  free(v);
  free(force_x);
  free(force_y);
  free(mass);
}

/*
 * Prints statistics: time, N, final velocity, final center of mass
 */
void print_statistics(clock_t s, clock_t e,
		      float ut, float vt,
		      float xc, float xy)
{
  printf("%f\n", (double)(e-s)/CLOCKS_PER_SEC);
  printf("%d\n", N);
  printf("%d\n", time_steps);
  printf("%f %f\n", ut, vt);
  printf("%f %f\n", xc, xy);
}

/*
 * Updates the positions of the particles of a time step.
 */
void time_step(void) {
  //Update forces
  update_forces(x, y, force_x, force_y);
    
  //Update velocities and positions
  for(int i = 0; i < N; i++) {
    double ax = force_x[i]/mass[i];
    double ay = force_y[i]/mass[i];
    u[i] += ax*dt;
    v[i] += ay*dt;
    x[i] += u[i]*dt;
    y[i] += v[i]*dt;
    bounce(&x[i], &y[i], &u[i], &v[i]);
  }
}

/*
 * If a particle moves beyond any of the boundaries then bounce it back
 */
void bounce(double *x, double *y, double *u, double *v) {
  double W = 1.0f, H = 1.0f;
  if(*x > W) {
    *x = 2*W - *x;
    *u = -*u;
  }
    
  if(*x < 0) {
    *x = -*x;
    *u = -*u;
  }
    
  if(*y > H) {
    *y = 2*H - *y;
    *v = -*v;
  }
    
  if(*y < 0) {
    *y = -*y;
    *v = -*v;
  }
}

/*
 * Function for updating the forces of all the stars
 */
void update_forces(double *x, double *y, double *force_x, double *force_y) {
  //Set the forces to zero
  for(int i = 0; i < N; i++) {
    force_x[i] = 0;
    force_y[i] = 0;
  }
  //Update the forces
  for(int i = 0; i < N; i++) {
    for (int j = i + 1; j < N; j++) {
      double r = sqrt((x[i] - x[j])*(x[i] - x[j]) + (y[i] - y[j])*(y[i] - y[j]));
      double temp = -grav*mass[i]*mass[j]/((r + epsilon)*(r + epsilon)*(r + epsilon));
      force_x[i] += temp*(x[i] - x[j]);
      force_y[i] += temp*(y[i] - y[j]);
      force_x[j] -= temp*(x[i] - x[j]);
      force_y[j] -= temp*(y[i] - y[j]);
    }
  }
}

/*
 * The main method
 */
int main(int argc, char *argv[]) {
  //The first argument sets the number of time steps
  if (argc > 1) {
    time_steps = atoi(argv[1]);
  }

  //The third argument gives the case
  char *filename = NULL;
  if (argc > 2) {
    filename = argv[2];
  }
  int test = read_case(filename);
  if (test == 1){
    printf("Error: case instantiation failed.\n");
    return 1;
  }

  //Begin taking time
  long start = clock();
        
  //The main loop
  for(int i = 0; i < time_steps; i++) {
    time_step();
  }

  //Finish taking time
  long stop = clock();

  //Stop taking time and print elapsed time
  //Compute final statistics
  double vu = 0;
  double vv = 0;
  double sumx = 0;
  double sumy = 0;
  double total_mass = 0;
  for (int i = 0; i < N; i++){
    sumx += mass[i]*x[i];
    sumy += mass[i]*y[i];
    vu += u[i];
    vv += v[i];
    total_mass += mass[i];
  }
  double cx = sumx/total_mass;
  double cy = sumy/total_mass;

  print_statistics(start, stop, vu, vv, cx, cy);
    
  //Free memory
  free_case();
    
  return 0;
}
