/*
 * File: case_generator.c: generate a case to be simulated, with
 * galaxy-like initial conditions for a number of particles.
 */
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <time.h>

//Some constants and global variables
const double L = 1, W = 1, dt = 1e-3, alpha = 0.25, V = 50, epsilon = 1e-1, grav = 0.04; //grav should be 100/N
double *x, *y, *u, *v, *force_x, *force_y, *mass;

/*
 * Function for producing a random number between two double values
 */
double frand(double xmin, double xmax) {
  return xmin + (xmax-xmin)*rand()/RAND_MAX;
}

/*
 * Main function.
 */
int main(int argc, char *argv[]) {
  srand(0);

  //The first argument sets the number of particles
  int N = 0;
  if (argc > 1) {
    N = atoi(argv[1]);
  }

  if (N == 0){
    fprintf(stderr, "No particles requested, do nothing.\n");
    return 1;
  }

  printf("%d\n", N);
    
  //Initiate memory for the vectors
  x = (double *)malloc(N*sizeof(double));
  y = (double *)malloc(N*sizeof(double));
  u = (double *)malloc(N*sizeof(double));
  v = (double *)malloc(N*sizeof(double));
  force_x = (double *)calloc(N, sizeof(double));
  force_y = (double *)calloc(N, sizeof(double));
  mass = (double *)malloc(N*sizeof(double));
  
  //Set the initial values
  for(int i = 0; i < N; i++) {
    mass[i] = 1;
    double R = frand(0, L/4);
    double theta = frand(0, 2*M_PI);
    x[i] = L/2 + R*cos(theta);
    y[i] = W/2 + alpha*R*sin(theta);
    double R_prim = sqrt(pow(x[i] - L/2, 2) + pow(y[i] - W/2, 2));
    u[i] = -V*R_prim*sin(theta);
    v[i] = V*R_prim*cos(theta);
    printf("%lf %lf %lf %lf %lf\n",
	   mass[i], x[i], y[i], u[i], v[i]);
  }

  //Free memory
  free(x);
  free(y);
  free(u);
  free(v);
  free(force_x);
  free(force_y);
  free(mass);
  return 0;
}

