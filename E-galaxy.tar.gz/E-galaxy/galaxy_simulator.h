/*
 * File: galaxy_simulator.h
 * --------------
 * Header file for barnes_hutgalaxy_simulator.c
 */

#ifndef Barnes_Hut_galaxy_simulator_h
#define Barnes_Hut_galaxy_simulator_h
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

//Function declarations
double frand(double xmin, double xmax);
void printtime(clock_t s, clock_t e);
void display(void);
void time_step(void);
void bounce(double *x, double *y, double *u, double *v);
void update_forces(double *x, double *y, double *forceX, double *forceY);

#endif
