
# Barnes-Hut

The Barnes Hut algorithm for n-body simulation implemented in C. I wrote the code for an assignment in the course High Performance Computing and Programming at Uppsala University together with Alexander Bilock and Joel Backsell. The code compiles down to two executables, the galaxy simulator and the Barnes Hut implementation. The task was to optimise the code as far as possible. GLUT and OpenGl is used for visualization, which therefore does not work for Windows systems. 

https://github.com/schnorr/Barnes-Hut
https://github.com/KimTorberntsson/Barnes-Hut